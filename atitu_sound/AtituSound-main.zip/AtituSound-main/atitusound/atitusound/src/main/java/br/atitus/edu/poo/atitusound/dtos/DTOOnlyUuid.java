package br.atitus.edu.poo.atitusound.dtos;

import java.util.UUID;

public class DTOOnlyUuid {

	private UUID uuid;

	public UUID getUuid() {
		return uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}
	
}
