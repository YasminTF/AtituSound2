package br.atitus.edu.poo.atitusound.services;

import br.atitus.edu.poo.atitusound.entities.PlaylistEntity;

public interface PlaylistService extends GenericService<PlaylistEntity> {

}
