package br.atitus.edu.poo.atitusound;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtitusoundApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtitusoundApplication.class, args);
	}

}
