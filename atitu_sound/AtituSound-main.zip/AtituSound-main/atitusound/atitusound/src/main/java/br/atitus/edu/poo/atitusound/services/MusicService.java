package br.atitus.edu.poo.atitusound.services;

import br.atitus.edu.poo.atitusound.entities.MusicEntity;

public interface MusicService extends GenericService<MusicEntity>{
	

}
