package br.atitus.edu.poo.atitusound.services;

import br.atitus.edu.poo.atitusound.entities.ArtistEntity;

public interface ArtistService extends GenericService<ArtistEntity> {
	
}
